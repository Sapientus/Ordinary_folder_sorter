Hey, nice to meet you.
This sh\*t is created to clean your folder.
Just do it!
I hope it works.
